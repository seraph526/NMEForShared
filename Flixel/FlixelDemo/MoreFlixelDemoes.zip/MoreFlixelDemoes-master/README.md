MoreFlixelDemoes
================

**FlxCameraDemo:**<br/>

Demonstration of the HaxeFlixel camera (FlxCamera) features, avalible here:<br/>
http://www.haxeflixel.com/demos/flxcamera

Note: I also made a test while writting this demo, if application.nmmml : 
**<!--haxedef name="TRUE_ZOOM_OUT" /-->** is uncommented, the zoom out will not decrease the
view size, that is done by increasing the rendering area of the camera, (which decreases performance), 
this feature was left out of the demo because of issues related to the camera styles.
